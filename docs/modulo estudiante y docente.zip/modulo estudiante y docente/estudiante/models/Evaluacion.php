<?php

namespace base\modules\estudiante\models;

use Yii;
use yii\web\UploadFile;
use app\models\Cursada;

class Evaluacion extends \app\models\Cursada
{

    //const WEBROOT_PATH = '@webroot/data/uploads/cursos/';
    const WEBROOT_PATH = '@app/data/uploads/cursos/';


    public function verificarExamen($model = null)
    {
        $data = [];

        if(is_null($model))
        {
            $data['mensaje'] = 'error requerimiento cursada no encontrado';
            $data['error'] = true;
            return $data;
        }
        
        if($model->examen_dia_evaluacion == 0)
        {
            $data['mensaje'] = 'El tiempo de su evaluacion no ha comenzado';
            $data['error'] = true;
            return $data;   
        }
        else
        {
            if($model->examen_dia_evaluacion != 0)
                $dia_visible = $model->examen_dia_evaluacion;


                $fecha_actual = date('Y-m-d');

                if($model->fecha_inicio <= $fecha_actual)
                {
                    $fecha_inicio = explode('-',$model->fecha_inicio);
                    //fecha_actual
                    $anio   = date('Y');
                    $mes    = date('n');
                    $dia    = date('j');

                    //fecha inicio cursada
                    $anio_inicio= $fecha_inicio[0];
                    $mes_inicio = $fecha_inicio[1];
                    $dia_inicio = $fecha_inicio[2];


                    $maximo_dias_mes_inicio     = cal_days_in_month(CAL_GREGORIAN, $mes_inicio, $anio_inicio);
                    $dia_inicio_mas_visibilidad = $dia_inicio + $model->examen_dia_evaluacion;


                    if($mes_inicio == 12)
                    {
                        if($dia_inicio_mas_visibilidad > $maximo_dias_mes_inicio)
                        {   
                            $mes = $mes -11;
                            $anio = $anio+1;
                            $dia = $dia_inicio_mas_visibilidad - $maximo_dias_mes_inicio;

                            if($mes < 10)
                            {
                                $mes = '0'.$mes;
                            }
                            $fecha_visiblildad = $anio.'-'.$mes.'-'.$dia;

                            if($fecha_actual > $fecha_visiblildad)
                            {
                                
                                $data['mensaje'] = 'El tiempo de su evaluacion se ha termiando';
                                $data['error'] = true;
                                return $data;
                            }
                            return true;
                        }
                    }


                    if($dia_inicio_mas_visibilidad > $maximo_dias_mes_inicio)
                    {   
                        $mes = $mes +1;
                        $dia = $dia_inicio_mas_visibilidad - $maximo_dias_mes_inicio;

                        if($mes < 10)
                        {
                            $mes = '0'.$mes;
                        }
                        $fecha_visiblildad = $anio.'-'.$mes.'-'.$dia;

                        if($fecha_actual > $fecha_visiblildad)
                        {
                            
                            $data['mensaje'] = 'El tiempo de su evaluacion se ha termiando';
                            $data['error'] = true;
                            return $data;
                        }
                        return true;
                    }
                    else
                    {
                        if($mes <10)
                        {
                            $mes = '0'.$mes;
                        }
                        $fecha_compuesta = $anio.'-'.$mes.'-'.$dia_inicio_mas_visibilidad;
                        if($fecha_compuesta < $fecha_actual)
                        {
                            $data['mensaje'] = 'El tiempo de su evaluacion se ha termiando';
                            $data['error'] = true;
                            return $data;
                        }
                    }
                }
            }
        
    }
}
