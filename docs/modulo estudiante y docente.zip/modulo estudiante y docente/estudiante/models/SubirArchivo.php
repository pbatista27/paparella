<?php

namespace base\modules\estudiante\models;
use Yii;
use yii\base\Model;
use yii\web\UploadedFile;
use app\models\CursadaCalificacion;
use yii\helpers\ArrayHelper;
use app\models\Cursada;



class SubirArchivo extends CursadaCalificacion
{
    /**
     * @var UploadedFile
     */
    public $Archivo;
    public $id_cursada;
    public $archivo_estudiante;
    public $modelCalificaciones;
    public $nombreArchivo;
    public $id_estudiante;
    public $id_docente;
    public $fecha_subida;

    const WEBROOT_PATH  = '@app/data/uploads/cursos/examen/';
    const WEBROOT_UPLOAD   = '@app/data/uploads/cursos/';
	const WEB_UPLOAD       = '@app/data/uploads/cursos/';
   // const WEB_UPLOAD    = '@app/data/uploads/cursos/examen/';
    const APROBADO      = 0;
    const STATUS        = 0;


    public function attributes()
    {
        $attributes = [
            'id_cursada',
            'Archivo',
            'archivo_estudiante',
            'id_estudiante',
            'id_docente',
            'fecha_subida',
            'nombreArchivo',
        ];

        return ArrayHelper::merge(parent::attributes(), $attributes);
    }

    public function getFile($webroot = false)
	{
		if(is_null($this->Archivo))
			return;

		$file = Yii::getAlias(static::WEBROOT_UPLOAD) . $this->Archivo;

		if(!is_file($file))
			return;

		if($webroot === true)
			return $file;
		else
			return Yii::getAlias(static::WEB_UPLOAD) . $this->Archivo;
    }
    
    public function getFileExtension()
	{
		try{
			return strtolower(pathinfo($this->getFile(true), PATHINFO_EXTENSION));
		}
		catch(\Exception $e){
			return null;
		}
	}

	public function hasFile()
	{
		return $this->getFile() ? true : false;
	}

    public function rules()
    {
        $rules = [
            [['id_cursada','Archivo'],'required'],
            [['id_cursada'], 'exist', 'skipOnError' => true, 'targetClass' => Cursada::className(), 'targetAttribute' => ['id_cursada' => 'id']],
            [['Archivo'], 'file', 'skipOnEmpty' => false, 'extensions' => 'docx , doc'],
            [['archivo_estudiante','id_estudiante','fecha_subida','id_docente'],'safe'],
        ];
        return $rules;
    }

    public function Scenarios()
    {
        $scenarios = parent::Scenarios();
        $scenarios['SUBIR_EXAMEN'] = ['id_cursada','Archivo','archivo_estudiante','fecha_subida','id_estudiante','id_docente'];

        return $scenarios;
    }


    public function attributeLabels()
    {
        return [
            'id_cursada' => Yii::t('app','Cursada'),
        ];
    }


    public function verificarExamen()
    {
        $data = []; 

        $model = \app\models\Cursada::findOne($this->id_cursada);

        if(is_null($model))
        {
            $data['mensaje'] = 'error requerimiento cursada no encontrado';
            $data['error'] = true;
            return $data;
        }
        
        if($model->examen_dia_evaluacion == 0)
        {
            $data['mensaje'] = 'El tiempo de su evaluacion no ha comenzado';
            $data['error'] = true;
            return $data;   
        }
        else
        {
            if($model->examen_dia_evaluacion != 0)
                $dia_visible = $model->examen_dia_evaluacion;


                $fecha_actual = date('Y-m-d');

                if($model->fecha_inicio <= $fecha_actual)
                {
                    $fecha_inicio = explode('-',$model->fecha_inicio);
                    //fecha_actual
                    $anio   = date('Y');
                    $mes    = date('n');
                    $dia    = date('j');

                    //fecha inicio cursada
                    $anio_inicio= $fecha_inicio[0];
                    $mes_inicio = $fecha_inicio[1];
                    $dia_inicio = $fecha_inicio[2];


                    $maximo_dias_mes_inicio     = cal_days_in_month(CAL_GREGORIAN, $mes_inicio, $anio_inicio);
                    $dia_inicio_mas_visibilidad = $dia_inicio + $model->examen_dia_evaluacion;


                    if($mes_inicio == 12)
                    {
                        if($dia_inicio_mas_visibilidad > $maximo_dias_mes_inicio)
                        {   
                            $mes = $mes -11;
                            $anio = $anio+1;
                            $dia = $dia_inicio_mas_visibilidad - $maximo_dias_mes_inicio;

                            if($mes < 10)
                            {
                                $mes = '0'.$mes;
                            }
                            $fecha_visiblildad = $anio.'-'.$mes.'-'.$dia;

                            if($fecha_actual > $fecha_visiblildad)
                            {
                                
                                $data['mensaje'] = 'El tiempo de su evaluacion se ha termiando';
                                $data['error'] = true;
                                return $data;
                            }
                            return true;
                        }
                    }


                    if($dia_inicio_mas_visibilidad > $maximo_dias_mes_inicio)
                    {   
                        $mes = $mes +1;
                        $dia = $dia_inicio_mas_visibilidad - $maximo_dias_mes_inicio;

                        if($mes < 10)
                        {
                            $mes = '0'.$mes;
                        }
                        $fecha_visiblildad = $anio.'-'.$mes.'-'.$dia;

                        if($fecha_actual > $fecha_visiblildad)
                        {
                            
                            $data['mensaje'] = 'El tiempo de su evaluacion se ha termiando';
                            $data['error'] = true;
                            return $data;
                        }
                        return true;
                    }
                    else
                    {
                        if($mes <10)
                        {
                            $mes = '0'.$mes;
                        }
                        $fecha_compuesta = $anio.'-'.$mes.'-'.$dia_inicio_mas_visibilidad;
                        if($fecha_compuesta < $fecha_actual)
                        {
                            $data['mensaje'] = 'El tiempo de su evaluacion se ha termiando';
                            $data['error'] = true;
                            return $data;
                        }
                    }
                }
            }
        
    }
    
    public function upload()
    {
        $this->nombreArchivo = $this->Archivo->baseName.'_'.microtime().'.'.$this->Archivo->extension;
        if ($this->validate()) {
            $this->Archivo->saveAs(Yii::getAlias(static::WEBROOT_PATH) . $this->nombreArchivo);
            return true;
        } else {
            return false;
        }
    }


    public function obtenerDocenteCursada($id_cursada = NULL)
    {

        $sql ='SELECT u.id
        FROM cursada_docente AS cd
        INNER JOIN cursada AS c ON c.id = cd.id_cursada
        INNER JOIN usuario AS u ON u.id = cd.id_docente
        INNER JOIN usuario_sucursal AS us ON us.id_usuario = u.id
        INNER JOIN curso_sucursal AS cs ON cs.id_sucursal = us.id_sucursal
        INNER JOIN curso AS cu ON cu.id = cs.id_curso
        WHERE u.activo = 1
        AND u.id_perfil = 3
        AND c.id = '.$id_cursada;

        $query = Yii::$app->db->createCommand($sql)->queryOne();


        $this->id_docente = $query['id']; 
    }

    public function save($runValidation = true, $attributeNames = NULL)
    {

        $this->obtenerDocenteCursada($this->id_cursada);
        
       
        $this->modelCalificaciones = new CursadaCalificacion();
        
        $this->id_estudiante                            = Yii::$app->user->identity->id;
        $this->modelCalificaciones->id_cursada          = $this->id_cursada;
        $this->modelCalificaciones->id_docente          = $this->id_docente;
        $this->modelCalificaciones->id_estudiante       = $this->id_estudiante;
        $this->modelCalificaciones->archivo_estudiante  = $this->nombreArchivo;
        $this->modelCalificaciones->fecha_subida        = date('Y-m-d');
        $this->modelCalificaciones->aprobado            = static::APROBADO;
        $this->modelCalificaciones->status              = static::STATUS;

        $status = $this->modelCalificaciones->save();

        if($status)
        {
            return true;
        }
        else
        {
            return false;
        }
		
    }
}