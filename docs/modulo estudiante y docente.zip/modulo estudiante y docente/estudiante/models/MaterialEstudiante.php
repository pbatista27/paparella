<?php

namespace base\modules\estudiante\models;

use Yii;
use yii\web\UploadFile;

class MaterialEstudiante extends \app\models\CursoContenido
{

    const WEBROOT_PATH = '@app/data/uploads/cursos/';
}
