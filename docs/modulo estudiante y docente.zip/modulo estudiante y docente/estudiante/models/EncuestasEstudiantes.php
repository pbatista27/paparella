<?php

namespace base\modules\estudiante\models;

use yii;
use yii\helpers\ArrayHelper;


class EncuestasEstudiantes extends \app\models\EncuestaSucursales
{

    
    
}
