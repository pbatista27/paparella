<?php

namespace app\base\modules\estudiante\controllers;

use base\Controller;
use Yii;
use base\modules\estudiante\models\Evaluacion;
use yii\data\ActiveDataProvider;
use yii\web\HttpException;
use yii\web\MethodNotAllowedHttpException;
use yii\helpers\Inflector;
use yii\web\UnauthorizedHttpException;
use app\models\Sucursal;
use app\models\Curso;
use yii\helpers\ArrayHelper;


class EvaluacionController extends Controller
{

    public $model;
    const PERFIL_ESTUDIANTE     = 4;
    const DOCUMENTO_EXAMEN      = 4;
    const DOCUMENTO_PROHIBIDO   = 2;
    

    public function actionIndex()
    {
        $query = Sucursal::find()
        ->select('s.id, s.nombre')
        ->from(Sucursal::tableName() . ' as s')
        ->join('INNER JOIN','usuario_sucursal as us', 'us.id_sucursal = s.id')
        ->join('INNER JOIN','usuario as u', 'u.id = us.id_usuario')
        ->andWhere('u.activo = 1')
        ->andWhere('u.id_perfil ='.static::PERFIL_ESTUDIANTE)
        ->andWhere('u.id = '.Yii::$app->user->identity->id);


        $dataSucursal = ArrayHelper::map($query->all(),'id', 'nombre');

        $this->view->H1             = Yii::t('app','Estudiante / Examen');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'file-text' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];

        return $this->renderAjax('index',['dataSucursal'=>$dataSucursal]);
        
    }

    public function actionCurso()
    {
        if(Yii::$app->request->isPost)
        {
            if(Yii::$app->request->isAjax == false)
                throw new MethodNotAllowedHttpException(Yii::t('app', 'Petición invalida.'));

            $id = Yii::$app->request->post('id');
        
        
           /* $query = Curso::find()
                    ->select('c.id, c.nombre')
                    ->from(Curso::tableName() . ' as c')
                    ->join('INNER JOIN','curso_sucursal as cs', 'cs.id_curso = c.id')
                    ->join('INNER JOIN','sucursal as s', 's.id = cs.id_sucursal')
                    ->join('INNER JOIN','usuario_sucursal as us', 'us.id_sucursal = s.id')
                    ->join('INNER JOIN','usuario as u', 'u.id = us.id_usuario')
                    ->join('INNER JOIN', 'cursada as cu', 'cu.id_curso_sucursal = cs.id')
                    ->join('INNER JOIN', 'cursada_estudiante as ce', 'ce.id_cursada = cu.id')
                    ->andWhere('u.activo = 1')
                    ->andWhere('s.id =:id',[':id'=>$id])
                    ->andWhere('u.id_perfil='.static::PERFIL_ESTUDIANTE)
                    ->andWhere('u.id = '.Yii::$app->user->identity->id)
                    ->andWhere('ce.id_estudinte = '. Yii::$app->user->identity->id);*/

                $query = Curso::find()
                    ->select('c.id, c.nombre')
                    ->from(Curso::tableName() . ' as c')
                    ->join('INNER JOIN','curso_sucursal as cs', 'cs.id_curso = c.id')
                    ->join('INNER JOIN','sucursal as s', 's.id = cs.id_sucursal')
                    ->join('INNER JOIN','usuario_sucursal as us', 'us.id_sucursal = s.id')
                    ->join('INNER JOIN','usuario as u', 'u.id = us.id_usuario')
                    ->join('INNER JOIN', 'cursada as cu', 'cu.id_curso_sucursal = cs.id')
                    ->join('INNER JOIN', 'cursada_estudiante as ce','ce.id_cursada = cu.id')
                    ->andWhere('u.activo = 1')
                    ->andWhere('s.id =:id',[':id'=>$id])
                    ->andWhere('u.id_perfil='.static::PERFIL_ESTUDIANTE)
                    ->andWhere('u.id = '.Yii::$app->user->identity->id)
                    ->andWhere('ce.id_estudiante = '. Yii::$app->user->identity->id);

            $dataCurso = $query->all();

            if(!is_null($dataCurso) && count($dataCurso) > 0 )
            {
                echo '<option value="">Seleccione Curso</option>';
                
                foreach($dataCurso as $curso){
                    echo "<option value='".$curso['id']."'>".$curso['nombre']."</option>";
                }
            }
            else
            {
                echo "<option value=''>no hay contenido</option>";
            }
        }
    }

    public function actionDocumentos()
    {
        if(Yii::$app->request->isPost)
        {
            if(Yii::$app->request->isAjax == false)
                throw new MethodNotAllowedHttpException(Yii::t('app', 'Petición invalida.'));

            $id     = Yii::$app->request->post('id');
            
            $sql    = Evaluacion::find()
                    ->select('c.id, c.examen')
                    ->from(Evaluacion::tableName() . ' as c')
                    ->join('INNER JOIN','cursada_estudiante as ce', 'ce.id_cursada = c.id')
                    ->join('INNER JOIN','usuario as u', 'u.id = ce.id_estudiante')
                    ->join('INNER JOIN', 'curso_sucursal as cs', 'cs.id = c.id_curso_sucursal')
                    ->join('INNER JOIN', 'curso as cu', 'cu.id = cs.id_curso')
                    ->join('INNER JOIN', 'curso_contenido as ccont', 'ccont.id_curso = cu.id')
                    ->where('cu.id = :id',[':id'=>$id])
                    ->andWhere('ccont.id_tipo_contenido = '. static::DOCUMENTO_EXAMEN)
                    ->andWhere('u.activo=1')
                    ->andWhere('u.id_perfil='.static::PERFIL_ESTUDIANTE)
                    ->andWhere('u.id=' . Yii::$app->user->identity->id);


        $this->model = new ActiveDataProvider([
            'query'      => $sql,
            'pagination' => false,
            'sort' => ['defaultOrder'=>'created_at desc']
        ]);
           
        }
        return $this->renderAjax('partial/_gridView');
    }

  
    public function actionDescargar($id = null)
    {

        $file = $this->findModel($id);
        
        $data = $file->verificarExamen($file);

        if($data['error'])
        {
            throw new UnauthorizedHttpException(Yii::t('app', $data['mensaje']));
        }

        $src = (Yii::getAlias($file::WEBROOT_PATH . $file->examen, false))?: false;

        if(!$src || !is_file($src) || !is_readable($src) )
            throw new HttpException( 404, Yii::t('app', 'Contenido no disponible') );

        $ext = pathinfo($src, PATHINFO_EXTENSION);
        $fileName = Inflector::slug($file->examen) . ($ext ? '.'.$ext : null );

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        header('Content-Type: ' . finfo_file($finfo, $src));
        finfo_close($finfo);

        header('Content-Disposition: attachment; filename='. $fileName );
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');

        header('Content-Length: ' . filesize($src));
        ob_clean();
        flush();
        readfile($src);
    }
    

    protected function findModel($id)
	{
		$query = Evaluacion::find()->where('id=:id', [
			'id' => $id,
		]);

		$file = $query->one();

		if($query->count() == 0)
			throw new HttpException( 404, Yii::t('app', 'Contenido no disponible') );

		return $query->one();
	}

}
