<?php

namespace app\base\modules\estudiante\controllers;

use Yii;
use base\Controller;
use base\widgets\ActiveForm;
use yii\web\MethodNotAllowedHttpException;
use yii\web\HttpException;
use yii\web\Session;
use app\models\Sucursal;
use yii\helpers\ArrayHelper;
use base\modules\estudiante\models\EncuestasEstudiantes;

/**
 * Default controller for the `estudiante` module
 */
class DefaultController extends Controller
{

    public $model;
    /**
     * Renders the index view for the module
     * @return string
     */


    public function actionIndex()
    {

        $this->view->H1             = Yii::t('app',' Seleccione sucursal');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'bank' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];

        $query = Sucursal::find()
            ->select('s.id,s.nombre')
            ->from(Sucursal::tableName(). ' as s')
            ->join('INNER JOIN','usuario_sucursal as us','us.id_sucursal= s.id')
            ->join('INNER JOIN','usuario as u','u.id = us.id_usuario')
            ->andWhere('s.activo=1')
            ->andWhere('u.activo=1')
            ->andWhere('u.id = :id',[':id'=>Yii::$app->user->identity->id]);
     
        $this->model = ArrayHelper::map($query->asArray()->all(),'id','nombre');

        return $this->renderAjax('index');
        
    }

    public function actionOpinion($id = null)
    {
        $this->view->H1             = Yii::t('app',' Estudiante / Danos tu Opinio');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'comments-o' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];

        $this->model                    = EncuestasEstudiantes::find()->where(['id_usuario'=>Yii::$app->user->identity->id,'id_sucursal'=>$id])->one();
        if(is_null($this->model))
            $this->model                = new EncuestasEstudiantes();
            $this->model->id_sucursal   = Sucursal::find()->select('id')->where('id = :id',[':id'=>$id])->one();
            if(is_null($this->model->id_sucursal))
                throw new HttpException( 404, Yii::t('app', 'Contenido no disponible') );
            $this->model->id_usuario    = Yii::$app->user->identity->id;

        $session = new Session();
        $session->open();
        $session->set('model',$this->model);

       return $this->renderAjax('opinion');
    }

    public function actionGuardarEncuesta()
    {
        if(Yii::$app->request->isPost)
        {
            if(Yii::$app->request->isAjax == false)
                throw new MethodNotAllowedHttpException(Yii::t('app', 'Petición invalida.'));

            $this->model = Yii::$app->session->get('model');

            $this->model->load(Yii::$app->request->post());

            if(isset($_POST['ajax']))
                return $this->asJson( ActiveForm::validate($this->model) );

            if($this->model->save())
            {

                return $this->asJson([
                    'status'     => true,
                    'statusCode' => Yii::t('app','Accion completada!'),
                    'statusText' => Yii::t('app', 'Registro actualizado exitosamente'),
                ]);
            }
            else
                return $this->asJson([
                    'status' => false,
                    'statusText' => Yii::t('app','Error actualizar datos de encuesta'),
                ]);
        }
        $this->redirect(['/estudiante/opinion']);
    }

}
