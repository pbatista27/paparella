<?php

namespace app\base\modules\estudiante\controllers;

use Yii;
use base\Controller;
use base\modules\estudiante\models\SubirArchivo;
use yii\web\UploadedFile;
use app\models\Cursada;
use yii\helpers\ArrayHelper;
use yii\web\HttpException;
use yii\web\MethodNotAllowedHttpException;
use yii\web\UnauthorizedHttpException;
/**
 * Default controller for the `estudiante` module
 */
class SubirArchivoController extends Controller
{

    public $model;
    const PERFIL_ESTUDIANTE = 4;
    /**
     * Renders the index view for the module
     * @return string
     */


    public function actionIndex()
    {

        
        $this->view->H1             = Yii::t('app','Estudiante / Subir Examen');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'folder' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];


        $sql ='SELECT c.id,cu.nombre
        FROM cursada_estudiante AS ce
        INNER JOIN cursada AS c ON c.id = ce.id_cursada
        INNER JOIN usuario AS u ON u.id = ce.id_estudiante
        INNER JOIN usuario_sucursal AS us ON us.id_usuario = u.id
        INNER JOIN curso_sucursal AS cs ON cs.id_sucursal = us.id_sucursal
        INNER JOIN curso AS cu ON cu.id = cs.id_curso
        WHERE u.activo = 1
        AND u.id_perfil = 4
        AND u.id = '. Yii::$app->user->identity->id;

        $data = Yii::$app->db->createCommand($sql)->queryAll();

        $dataCursada = ArrayHelper::map($data,'id', 'nombre');
        $this->model  = new SubirArchivo(['scenario' => 'SUBIR_EXAMEN']);

        if (Yii::$app->request->isPost) 
        {

            $this->model->load(Yii::$app->request->post());
            $id = $this->model->id_cursada;

            $count = \app\models\CursadaCalificacion::find()->where('id_cursada = :id',[':id'=>$id])->andWhere(['id_estudiante'=>Yii::$app->user->identity->id])->count();

            if($count > 0)
            {
                throw new UnauthorizedHttpException(Yii::t('app','Ya usted ha subido un examen a este curso'));
            }

            //verificar y valida la fecha para subir examen
            $data = $this->model->verificarExamen();

            if($data['error'])
            {
                throw new UnauthorizedHttpException(Yii::t('app', $data['mensaje']));
            }

            $this->model->Archivo = UploadedFile::getInstance($this->model, 'Archivo');

            if($this->model->validate())
            {
                if ($this->model->upload()) 
                {
                   if($this->model->save())
                   {
                       
                    return $this->asJson([
                        'status' 	 => true,
                        'statusText' => Yii::t('app', 'archivo subido con exito'),
                    ]);
                   }
                   else
                   {
                    return $this->asJson([
                        'status' 	 => false,
                        'statusText' => Yii::t('app', 'Error al guardar los datos.. favor intente más tarde'),
                        'errors'	 => $this->model->getErrors(),
                    ]);
                   }
                }
                else
                {
                    Yii::$app->session->setFlash('danger','ocurrio un error al subir el archivo');
                    return $this->asJson([
                        'status' 	 => false,
                        'statusText' => Yii::t('app', 'Ocurrio un error al subir el archivo'),
                        'errors'	 => $this->model->getErrors(),
                    ]);
                }
            }
        }
        return $this->renderAjax('index',['dataCursada'=>$dataCursada]);
    }

}