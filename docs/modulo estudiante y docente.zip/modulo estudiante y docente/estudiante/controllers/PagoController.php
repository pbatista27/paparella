<?php

namespace app\base\modules\estudiante\controllers;

use Yii;
use base\Controller;
use yii\data\ActiveDataProvider;
use app\models\CursadaPago;

/**
 * Default controller for the `estudiante` module
 */
class PagoController extends Controller
{

    public $model;
    /**
     * Renders the index view for the module
     * @return string
     */


    public function actionIndex()
    {

        $fecha_actual = date('Y-m-d');

        $params = [
                'atrasados'     => new ActiveDataProvider([
                'query'         => CursadaPago::find()
                                    ->where('status = 0')
                                    ->andWhere(['<','fecha_cobro',$fecha_actual])
                                    ->andWhere('id_estudiante = '. Yii::$app->user->identity->id),
                'pagination'    => false,
                'sort' => ['defaultOrder'=>'created_at desc']
            ]),

            'faltantes' => new ActiveDataProvider([
                'query'      => CursadaPago::find()
                                ->where('status = 0')
                                ->andWhere(['>=','fecha_cobro',$fecha_actual])
                                ->andWhere('id_estudiante = '. Yii::$app->user->identity->id),
                'pagination' => false,
                'sort' => ['defaultOrder'=>'created_at desc']
            ]),

                'realizados'   => new ActiveDataProvider([
                'query'         => CursadaPago::find()->where('status = 1')->andWhere('id_estudiante = '.Yii::$app->user->identity->id),
                'pagination'    => false,
                'sort' => ['defaultOrder'=>'created_at desc']
            ]),
        
            ];
        
        $this->view->H1             = Yii::t('app','Estudiante / Pagos');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'money' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];

        return $this->renderAjax('index',$params);
    }

}