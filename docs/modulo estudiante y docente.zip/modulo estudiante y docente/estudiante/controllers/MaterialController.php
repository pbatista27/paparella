<?php

namespace app\base\modules\estudiante\controllers;

use Yii;
use base\Controller;
use base\widgets\ActiveForm;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;
use app\models\Sucursal;
use base\modules\estudiante\models\MaterialEstudiante;
use app\models\Curso;
use yii\web\HttpException;
use yii\web\MethodNotAllowedHttpException;
use yii\helpers\Inflector;
use yii\web\UnauthorizedHttpException;
/**
 * Default controller for the `estudiante` module
 */
class MaterialController extends Controller
{

    public $model;
    const PERFIL_ESTUDIANTE     = 4;
    //docuemnteo solo para profesores
    const DOCUMENTO_PROHIBIDO  = 2;
    const DOCUMENTO_EXAMEN     = 4;
    /**
     * Renders the index view for the module
     * @return string
     */


    public function actionIndex()
    {
        $query = Sucursal::find()
        ->select('s.id, s.nombre')
        ->from(Sucursal::tableName() . ' as s')
        ->join('INNER JOIN','usuario_sucursal as us', 'us.id_sucursal = s.id')
        ->join('INNER JOIN','usuario as u', 'u.id = us.id_usuario')
        ->andWhere('u.activo = 1')
        ->andWhere('u.id_perfil ='.static::PERFIL_ESTUDIANTE)
        ->andWhere('u.id = '.Yii::$app->user->identity->id);


        $dataSucursal = ArrayHelper::map($query->all(),'id', 'nombre');

        $this->view->H1             = Yii::t('app','Estudiante / Material curso');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'folder' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];

        return $this->renderAjax('index',['dataSucursal'=>$dataSucursal]);
        
    }

    public function actionCurso()
    {
        if(Yii::$app->request->isPost)
        {
            if(Yii::$app->request->isAjax == false)
                throw new MethodNotAllowedHttpException(Yii::t('app', 'Petición invalida.'));

            $id = Yii::$app->request->post('id');
        
        
            $query = Curso::find()
                    ->select('c.id, c.nombre')
                    ->from(Curso::tableName() . ' as c')
                    ->join('INNER JOIN','curso_sucursal as cs', 'cs.id_curso = c.id')
                    ->join('INNER JOIN','sucursal as s', 's.id = cs.id_sucursal')
                    ->join('INNER JOIN','usuario_sucursal as us', 'us.id_sucursal = s.id')
                    ->join('INNER JOIN','usuario as u', 'u.id = us.id_usuario')
                    ->join('INNER JOIN', 'cursada as cu', 'cu.id_curso_sucursal = cs.id')
                    ->join('INNER JOIN', 'cursada_estudiante as ce','ce.id_cursada = cu.id')
                    ->andWhere('s.id =:id',[':id'=>$id])
                    ->andWhere('u.activo = 1')
                    ->andWhere('u.id_perfil='.static::PERFIL_ESTUDIANTE)
                    ->andWhere('u.id = '.Yii::$app->user->identity->id)
                    ->andWhere('ce.id_estudiante = '. Yii::$app->user->identity->id);

            $dataCurso = $query->all();

            if(!is_null($dataCurso) && count($dataCurso) > 0)
            {
                echo '<option value="">Seleccione Curso</option>';
                
                foreach($dataCurso as $curso){
                    echo "<option value='".$curso['id']."'>".$curso['nombre']."</option>";
                }
            }
            else
            {
                echo "<option value=''>no hay contenido</option>";
            }
        }
    }


    public function actionDocumentos()
    {
        if(Yii::$app->request->isPost)
        {
            if(Yii::$app->request->isAjax == false)
                throw new MethodNotAllowedHttpException(Yii::t('app', 'Petición invalida.'));

            $id     = Yii::$app->request->post('id');
            $tipo   = Yii::$app->request->post('tipo');
            
            if($tipo == static::DOCUMENTO_PROHIBIDO)
            {
                throw new MethodNotAllowedHttpException(Yii::t('app', 'Petición invalida.'));
                
            }
                
            //si tipo es null trae por defecto todo los programas del estudinte
            if(is_null($tipo))
            {

                $sql = MaterialEstudiante::find()
                ->select('ccont.id, ccont.nombre, ccont.archivo')
                ->from(MaterialEstudiante::tableName() . ' as ccont')
                ->join('INNER JOIN','curso_sucursal as cs', 'cs.id_curso = ccont.id_curso')
                ->join('INNER JOIN','cursada as c', 'c.id_curso_sucursal = cs.id')
                ->join('INNER JOIN','curso as cu', 'cu.id = cs.id_curso')
                ->join('INNER JOIN','sucursal as s', 's.id = cs.id_sucursal')
                ->andWhere('ccont.id_tipo_contenido = 1')
                ->andWhere('cu.activo=1')
                ->andWhere('cu.id = :id',[':id'=>$id]);
            }
            else
            {

                if($tipo == static::DOCUMENTO_EXAMEN)
                {
                    return false;
                    $sql = MaterialEstudiante::find()
                    ->select('ccont.id, ccont.nombre, ccont.archivo')
                    ->from(MaterialEstudiante::tableName() . ' as ccont')
                    ->join('INNER JOIN','curso_sucursal as cs', 'cs.id_curso = ccont.id_curso')
                    ->join('INNER JOIN','cursada as c', 'c.id_curso_sucursal = cs.id')
                    ->join('INNER JOIN','curso as cu', 'cu.id = cs.id_curso')
                    ->join('INNER JOIN','sucursal as s', 's.id = cs.id_sucursal')
                    ->join('INNER JOIN', 'usuario_sucursal as us','us.id_sucursal= s.id')
                    ->join('INNER JOIN','usuario as u','u.id = us.id_usuario')
                    ->andWhere('ccont.id_tipo_contenido = :tipo',[':tipo'=>$tipo])
                    ->andWhere('cu.activo=1')
                    ->andWhere('cu.id = :id',[':id'=>$id])
                    ->andWhere('u.activo=1')
                    ->andWhere('u.id_perfil='.static::PERFIL_ESTUDIANTE)
                    ->andWhere('c.status=1')
                    ->andWhere('u.id=' . Yii::$app->user->identity->id);
                }
                else
                {
                    $sql = MaterialEstudiante::find()
                    ->select('ccont.id, ccont.nombre, ccont.archivo')
                    ->from(MaterialEstudiante::tableName() . ' as ccont')
                    ->join('INNER JOIN','curso_sucursal as cs', 'cs.id_curso = ccont.id_curso')
                    ->join('INNER JOIN','cursada as c', 'c.id_curso_sucursal = cs.id')
                    ->join('INNER JOIN','curso as cu', 'cu.id = cs.id_curso')
                    ->join('INNER JOIN','sucursal as s', 's.id = cs.id_sucursal')
                    ->andWhere('ccont.id_tipo_contenido = :tipo',[':tipo'=>$tipo])
                    ->andWhere('cu.activo=1')
                    ->andWhere('cu.id = :id',[':id'=>$id]);
                }
            } 
            
            
            $this->model = new ActiveDataProvider([
                'query'      => $sql,
                'pagination' => false,
                'sort' => ['defaultOrder'=>'created_at desc']
            ]);
           
        }
        return $this->renderAjax('gridView');
    }



    public function actionDescargar($id = null)
    {

        $file = $this->findModel($id);
        
        /*$data = $this->verificarExamen($file);

        if($data['error'])
        {
            throw new UnauthorizedHttpException(Yii::t('app', $data['mensaje']));
        }*/

        $src = (Yii::getAlias($file::WEBROOT_PATH . $file->archivo, false))?: false;

        if(!$src || !is_file($src) || !is_readable($src) )
            throw new HttpException( 404, Yii::t('app', 'Contenido no disponible') );

        $ext = pathinfo($src, PATHINFO_EXTENSION);
        $fileName = Inflector::slug($file->nombre) . ($ext ? '.'.$ext : null );

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        header('Content-Type: ' . finfo_file($finfo, $src));
        finfo_close($finfo);

        header('Content-Disposition: attachment; filename='. $fileName );
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');

        header('Content-Length: ' . filesize($src));
        ob_clean();
        flush();
        readfile($src);
    }
    

    protected function findModel($id)
	{
		$query = MaterialEstudiante::find()->where('id=:id', [
			'id' => $id,
		]);

		$file = $query->one();

		if($query->count() == 0)
			throw new HttpException( 404, Yii::t('app', 'Contenido no disponible') );

		return $query->one();
	}

}