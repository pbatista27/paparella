<?php
	use yii\helpers\Url;
	use base\widgets\ActiveForm;
	use yii\helpers\Html;
	use yii\helpers\ArrayHelper;
    use base\widgets\faicons\Fa;

    $this->registerJs(
        '
            (function(){

                modal.reset.default();

                modal.icon.attr("class", "fa fa-'. $this->iconClass .' fa-fw");
                modal.title.html("'. $this->H1 .'");
                modal.size("modal-70")
                modal.header.show();
                modal.header.btnClose.show();
                modal.body.show();
                modal.footer.hide();
            })();
        '
    );
?>
<div class="row estudiante-opinion">
	<div class="col-lg-12 col-md-12 col-sm-12">
        <div class='row'>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <h3 class="text-center" style="text-decoration:underline">COMPARTI TU EXPERIENCIA CON NOSOTROS</h3>
            </div>
            <br><br>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <p class="text-center">
                    Para brindarte un mejor servicio, es importante para nosotros contar con tu opinión. Te pedimos solo unos segundos para completar esta encuesta:
                </p>
            </div>
            <hr>
            <br>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <?=$this->render('partial/_form');?>
            </div>
        </div>
	</div>
</div>