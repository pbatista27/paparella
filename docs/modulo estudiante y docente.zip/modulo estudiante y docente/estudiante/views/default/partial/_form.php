<?php
use base\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
use app\models\Sucursal;
use yii\helpers\ArrayHelper;
?>

<div class="row">
    <?php $form = ActiveForm::begin([
        'id'        => $this->context->model->formName(),
        'action'    =>  Url::toRoute(['/estudiante/guardar-encuesta']),
    ]); ?>
    <div class="col-md-12 col-sm-12">
        <div class="padding-top-15">
            <div class="row">
                <?php
                    echo $form->field($this->context->model, 'nivel_formacion', [ 'inputOptions' => ['autocomplete' => 'off'] , 'options' => ['class' => 'col-xs-12 col-sm-12 col-md-6 col-lg-6']])->radioList(array('malo'=>'1 MALO','regular'=>'2 REGULAR','bueno'=>'3 BUENO','muy bueno'=>'4 MUY BUENO','excelente'=>'5 EXCELENTE'))->label('¿Cómo evaluas el nivel de formacion recibido?'); 

                    echo $form->field($this->context->model, 'desempeno_docente', [ 'inputOptions' => ['autocomplete' => 'off'] , 'options' => ['class' => 'col-xs-12 col-sm-12 col-md-6 col-lg-6']])->radioList(array('malo'=>'1 MALO','regular'=>'2 REGULAR','bueno'=>'3 BUENO','muy bueno'=>'4 MUY BUENO','excelente'=>'5 EXCELENTE'))->label('¿Cómo evaluas el desempeño del docente a cargo?');  
                ?>
            </div>
            <hr>
            <div class="row">
            <?php
                    echo $form->field($this->context->model, 'clima_clase', [ 'inputOptions' => ['autocomplete' => 'off'] , 'options' => ['class' => 'col-xs-12 col-sm-12 col-md-6 col-lg-6']])->radioList(array('malo'=>'1 MALO','regular'=>'2 REGULAR','bueno'=>'3 BUENO','muy bueno'=>'4 MUY BUENO','excelente'=>'5 EXCELENTE'))->label('¿Cómo evaluas el clima general de las clases?');

                    echo $form->field($this->context->model, 'instalaciones', [ 'inputOptions' => ['autocomplete' => 'off'] , 'options' => ['class' => 'col-xs-12 col-sm-12 col-md-6 col-lg-6']])->radioList(array('malo'=>'1 MALO','regular'=>'2 REGULAR','bueno'=>'3 BUENO','muy bueno'=>'4 MUY BUENO','excelente'=>'5 EXCELENTE'))->label('¿Cómo evaluas las instalaciones donde cursaste?');
                ?>
            </div>
            <hr>
            <div class="row">
            <?php
                    echo $form->field($this->context->model, 'id_sucursal',[ 'inputOptions' => ['autocomplete' => 'off'] , 'options' => ['class' => 'hide-xs-12 hide-col-sm hide-col-md hide-col-lg']])->hiddenInput()->Label(false);
    
                    echo $form->field($this->context->model, 'comentario', [ 'inputOptions' => ['autocomplete' => 'off'] , 'options' => ['class' => 'col-xs-12 col-sm-12 col-md-12']])->textArea(['rows'=>'3'])->Label('Comentario :');
                ?>
            </div>
    </div>
    <div class="padding-top-15">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 text-left  margin-v-15">
                <?php echo Html::submitButton(Yii::t('app','Guardar'), ['class' => 'btn btn-primary', 'data-pjax' => 'false']);?>
            </div>
        </div>
    </div>
    <?php $form::end(); ?>
</div>