<?php
    use yii\helpers\Html;
    use yii\grid\GridView;
    use yii\helpers\Url;
    use base\widgets\faicons\Fa;
    use yii\widgets\Pjax;

    $this->registerJs(
        '
            (function(){
    
                modal.reset.default();
    
                modal.icon.attr("class", "fa fa-'. $this->iconClass .' fa-fw");
                modal.title.html("'. $this->H1 .'");
                modal.size("modal-70")
                modal.header.show();
                modal.header.btnClose.show();
                modal.body.show();
                modal.footer.hide();
            })();
        '
    );
?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
            
                <!--navs-->
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a data-toggle="tab" href="#atrasados" >
                            <?php echo Fa::icon('clock-o')->fw() .  Yii::t('app', 'Pagos Atrasados') . ' ('. $atrasados->getTotalCount() .')' ?>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#faltantes" >
                            <?php echo Fa::icon('eye')->fw() . Yii::t('app', 'Pagos Faltantes') . ' ('. $faltantes->getTotalCount() .')' ?>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#realizados">
                            <?php echo Fa::icon('check')->fw() . Yii::t('app', 'Pagos Realizados') . ' ('. $realizados->getTotalCount() .')' ?>
                        </a>
                    </li>
                </ul>

                <!--gridviews-->
                <div class="tab-content">
                    <!--actives-->
                    <div id="atrasados" class="tab-pane fade in active">
                        <div id="grid-actives" class="container-fluid">
                            <div class="row" >
                                <div class="col-sx-12">
                                    <div class="padding-h-15">
                                        <div class="padding-top-5">
                                            <div class="table-responsive">
                                                <?php
                                                    echo $this->render('partial/_gridViewAtrasado', [
                                                        'dataProvider' => $atrasados,
                                                    ]);
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="faltantes" class="tab-pane fade">
                        <div id="grid-inactives" class="container-fluid">
                            <div class="row" >
                                <div class="col-sx-12">
                                    <div class="padding-h-15">
                                        <div class="padding-top-5">
                                            <div class="table-responsive">
                                                <?php
                                                   echo $this->render('partial/_gridViewFaltante', [
                                                        'dataProvider' => $faltantes,
                                                    ]);
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="realizados" class="tab-pane fade">
                        <div id="grid-inactives" class="container-fluid">
                            <div class="row" >
                                <div class="col-sx-12">
                                    <div class="padding-h-15">
                                        <div class="padding-top-5">
                                            <div class="table-responsive">
                                                <?php
                                                   echo $this->render('partial/_gridViewRealizados', [
                                                        'dataProvider' => $realizados,
                                                    ]);
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>

