<?php
    use yii\helpers\Html;
    use yii\grid\GridView;
    use yii\widgets\Pjax;
?>

<div class="padding-top-5">
    <div class="table-responsive">
        <?php
        Pjax::begin([
            'enablePushState'=>false,
        ]);
            echo GridView::widget([
                'dataProvider'  => $dataProvider,
                'layout'        => '{items}',
                'tableOptions'  => ['class' => 'table'],
                //'caption'  => '<h3 class="text-center">TABLA DE CONTENIDO</h3>',
                'columns' => [
                    [
                        'attribute' =>'id_curso_sucursal',
                        'label'     => 'Sucursal',
                        'value'     => function($model)
                        {
                            return $model->getCursada()->one()->getCursoSucursal()->one()->getSucursal()->one()->nombre. ' - Curso : ' .$model->getCursada()->one()->getCursoSucursal()->one()->getCurso()->one()->nombre;
                        }
                    ],
                ],
            ]);
        Pjax::end();
        ?>
    </div>
</div>