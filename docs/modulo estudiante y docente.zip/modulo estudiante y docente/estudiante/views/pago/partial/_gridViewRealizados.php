<?php
    use yii\helpers\Html;
    use yii\grid\GridView;
    use yii\widgets\Pjax;
?>

<div class="padding-top-5">
    <div class="table-responsive">
        <?php
        Pjax::begin([
            'enablePushState'=>false,
        ]);
            echo GridView::widget([
                'dataProvider'  => $dataProvider,
                'layout'        => '{items}',
                'tableOptions'  => ['class' => 'table'],
                //'caption'  => '<h3 class="text-center">TABLA DE CONTENIDO</h3>',
                'columns' => [
                    [
                        'attribute' =>'id_curso_sucursal',
                        'label'     => 'Sucursal',
                        'value'     => function($model)
                        {
                            return $model->getCursada()->one()->getCursoSucursal()->one()->getSucursal()->one()->nombre;
                        }
                    ],
                    [
                        'attribute' =>'id_curso',
                        'label'     => 'Curso',
                        'value'     => function($model)
                        {
                            return $model->getCursada()->one()->getCursoSucursal()->one()->getCurso()->one()->nombre;
                        }
                    ],
                    [
                        'attribute' =>'id_cursada',
                        'label'     => 'Cursada',
                        'value'     => function($model)
                        {
                            return $model->getCursada()->one()->periodo;
                        }
                    ],
                    [
                        'attribute' =>'id_tipo_pago',
                        'label'     =>'Tipo Pago',
                        'value'     => function($model)
                        {
                            return $model->getTipoPago()->one()->codigo;
                        }
                    ],
                    [
                        'attribute' =>'nro_pago',
                    ],
                    [
                        'attribute' =>'descripcion',
                    ],
                    [
                        'attribute' =>'fecha_cobro',
                    ],
                    [
                        'attribute' =>'fecha_pago',
                    ],
                    [
                        'attribute' =>'status',
                        'label'     =>'Status',
                        'value'     => function($model)
                        {
                            return ($model->status == 0) ? 'No Pagado' : 'Pagado';
                        }
                    ],
                ],
            ]);
        Pjax::end();
        ?>
    </div>
</div>