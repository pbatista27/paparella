<?php
    use yii\helpers\Html;
    use yii\grid\GridView;
    use yii\helpers\Url;
    use base\widgets\faicons\Fa;
    use yii\widgets\Pjax;

     $contar = $this->context->model->getCount();
?>

<div class="padding-top-5">
    <div class="table-responsive">
        <?php
        if($contar == 0)
        {
            echo "<h3 class='text-center'>No hay Documentos</h3>";
            return false;

        }
        Pjax::begin([
            'enablePushState'=>false,
        ]);
            echo GridView::widget([
                'dataProvider'  => $this->context->model,
                'layout'        => '<div class="col-md-12  padding-b-10">{summary}</div>{items}<div class="col-md-12 text-center">{pager}<hr></div>',
                'tableOptions'  => ['class' => 'table table-hover table-bordered hide'],
                //'caption'  => '<h3 class="text-center">TABLA DE CONTENIDO</h3>',
                'columns' => [
                    [
                        'attribute' =>'nombre',
                        'label' =>'',
                        'content' => function($model)
                        {
                        ?>
                            <div class="col-md-3">
	                            <div style="border:1px solid #cecece; border-radius:6px; margin-bottom:30px">
		                            <div class="header text-center" style="padding-bottom:15px; border-bottom:1px solid #cecece; padding:20px 15px 10px">
			                            <h5><?= Html::encode($model->nombre) ?></h5>
		                            </div>
		                            <div class="body text-center" style="height:100px; padding: 15px;" >
			                            <a href="<?=Url::toRoute(['/estudiante/material/descargar','id'=>$model->id]);?>" target= "_blank" data-pjax="0" >
				                            <?= Fa::icon('download')->size('5x'); ?>
			                            </a>
		                            </div>
	                            </div>
                            </div>
                        <?php
                        },
                    ],
                ],
            ]);
        Pjax::end();
        ?>
    </div>
</div>

