<?php 
use yii\helpers\Url;
?>
<div class="col-md-3 col-sm-4">
    <div class="list-group">
        <a class="documentos list-group-item active" href="<?=Url::toRoute(['/estudiante/material/documentos']);?>" data-tipo='1'>
            <i class="glyphicon glyphicon-chevron-left"></i>
            Programa
        </a>
        <a class="documentos list-group-item" href="<?=Url::toRoute(['/estudiante/material/documentos'])?>" data-tipo='3'>
            <i class="glyphicon glyphicon-chevron-left"></i>
            Material
        </a>
    </div>
</div>