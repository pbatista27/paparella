<?php

namespace app\base\modules\estudiante;

use Yii;
use yii\helpers\Url;
use yii\web\UnauthorizedHttpException;
use base\models\UserIdentity;
use yii\web\NotFoundHttpException;

/**
 * estudiante module definition class
 */
class module extends \yii\base\Module
{
    /**
     * {@inheritdoc}
     */
    public $controllerNamespace = 'app\base\modules\estudiante\controllers';

    /**
     * {@inheritdoc}
     */
    public function init()
    {
        parent::init();

        $user  = Yii::$app->user;
        $route = Yii::$app->requestedRoute;

        
        if($user->isGuest)
        {
            $url = 'location: ' . Url::toRoute(Yii::$app->user->loginUrl);
            exit(header($url, false));
        }

        $this->checkAccess($route, $user->identity);
    }

    protected function checkAccess($route, $identity)
    {
        if($identity->id_perfil == $identity::PROFILE_ESTUDIANTE)
            return true;

        throw new UnauthorizedHttpException(Yii::t('app', 'Sin permisos para visualizar este contenido.'));
    }
}
