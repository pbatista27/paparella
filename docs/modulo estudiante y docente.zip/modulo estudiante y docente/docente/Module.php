<?php

namespace app\base\modules\docente;

/**
 * docente module definition class
 */
use Yii;
use yii\helpers\Url;
use yii\web\UnauthorizedHttpException;
use base\models\UserIdentity;
use yii\web\NotFoundHttpException;

class Module extends \yii\base\Module
{
    /**
     * {@inheritdoc}
     */
    public $controllerNamespace = 'app\base\modules\docente\controllers';

    /**
     * {@inheritdoc}
     */
    public function init()
    {
        parent::init();

        $user  = Yii::$app->user;
        $route = Yii::$app->requestedRoute;

        
        if($user->isGuest)
        {
            $url = 'location: ' . Url::toRoute(Yii::$app->user->loginUrl);
            exit(header($url, false));
        }

        $this->checkAccess($route, $user->identity);
    }

    protected function checkAccess($route, $identity)
    {
        if($identity->id_perfil == $identity::PROFILE_DOCENTE)
            return true;

        throw new UnauthorizedHttpException(Yii::t('app', 'Sin permisos para visualizar este contenido.'));
    }
}
