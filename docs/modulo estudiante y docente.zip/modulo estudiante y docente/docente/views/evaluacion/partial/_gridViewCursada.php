<?php
    use yii\helpers\Html;
    use yii\grid\GridView;
    use yii\helpers\Url;
    use base\widgets\faicons\Fa;
    use yii\widgets\Pjax;
?>

<div class="padding-top-5">
    <div class="table-responsive">
        <?php
            echo GridView::widget([
                'dataProvider'  => $this->context->model,
                'layout'        => '{items}',
                'tableOptions'  => ['class' => 'table' ],
                'columns' => [
                    // btn inhabilitar
                    ['class' => 'yii\grid\SerialColumn'],
                    [
                        'attribute'=>'id',
                        'header' =>'Cursos',
                        'value' => function($model)
                        {
                            return $model->getCursoSucursal()->one()->getCurso()->one()->nombre;
                        }
                    ],

                    // btn grid:
                    [
                        'class'             => 'yii\grid\ActionColumn',
                        'header'            => Yii::t('app', 'Acciones'),
                        'contentOptions'    => ['style' => 'width: 100px', 'class' => 'text-center'],
                        'template'          => '{view}',
                        'buttons'   => [

                            'view' => function ($url, $model, $key){
                                $link    = Url::toRoute(['/docente/evaluacion/examen' , 'id' => $model->getCursoSucursal()->one()->getCurso()->one()->id ]);
                                $text    = Fa::icon('arrow-right')->fw();

                                return Html::a($text, $link, [
                                    'title'         =>  Yii::t('yii', 'Ir a Evaluacion') ,
                                    'class'         => 'text-info',
                                ]);
                            },
                        ]
                    ],
                ],
            ]);
        ?>
    </div>
</div>
