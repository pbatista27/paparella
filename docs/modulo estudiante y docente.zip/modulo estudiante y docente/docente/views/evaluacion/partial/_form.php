<?php
    use yii\helpers\Url;
    use base\widgets\ActiveForm;
    use yii\helpers\Html;
    use base\widgets\faicons\Fa;
?>

<div class="docente-evaliacion-form">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading text-center">
                    <h3 class="panel-title text-center">
                        <?php echo Yii::t('app', 'Estudiante'); ?>
                    </h3>
                </div>
                <div class="panel-body" >
                    <div class="col-md-12 col-sm-12">
                        <div class="row">
                            <?php $form = ActiveForm::begin([
                                'id' => $this->context->model->formName(),
                                'action'    =>  Url::toRoute(['/docente/evaluacion/registrar-evaluacion']),
                            ]);?>

                            <div class="padding-top-15">
                                    <div class="row">
                                        <?php echo $form->field($this->context->model, 'aprobado',   [ 'inputOptions' => ['autocomplete' => 'off'] , 'options' => ['class' => 'col-xs-12 col-sm-12 col-md-12']])->dropDownList([1=>'Aprobado',0=>'Reprobado'],['prompt'=>'Selecione un opcion'])->Label('Evaluar :'); ?>
                                    </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 margin-v-15">
                                <?php echo Html::submitButton(Yii::t('app','Aceptar'), ['class' => 'btn btn-primary btn-block form-editar-evaluacion', 'data-pjax' => 'false']);?>
                            </div>
                            <?php ActiveForm::end()?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>