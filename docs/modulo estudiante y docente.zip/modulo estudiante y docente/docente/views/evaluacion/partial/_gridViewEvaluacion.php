<?php
    use yii\helpers\Html;
    use yii\grid\GridView;
    use yii\helpers\Url;
    use base\widgets\faicons\Fa;
?>

<div class="padding-top-5">
    <div class="table-responsive">
        <?php
            echo GridView::widget([
                'dataProvider'  => $this->context->model,
                'layout'        => '{items}',
                'tableOptions'  => ['class' => 'table' ],
                'columns' => [
                    // btn inhabilitar
                    ['class' => 'yii\grid\SerialColumn'],
                    [
                        'attribute' => 'id_estudiante',
                        'header'    => 'Nombres Estudiante',
                        'value'     => function($model)
                        {
                            return $model->getEstudiante()->one()->nombres.' '.$model->getEstudiante()->one()->apellidos;
                        }
                    ],
                    [
                        'attribute' => 'archivo_estudiante',
                        'header'    => 'Evaluacion',
                    ],
                    [
                        'attribute' => 'fecha_subida',
                        'header'    => 'Fecha Subida',
                    ],
                    [
                        'attribute' => 'aprobado',
                        'header'    => 'Aprobado',
                        'value'     => function($model)
                        {
                          return  ($model->aprobado == 0) ? 'Reprobado' : 'Aprobado';
                        }
                    ],
                    [
                        'attribute' => 'status',
                        'header'    => 'Status',
                        'value'     => function($model)
                        {
                            return ($model->status == 0) ? 'No Evaluado' :'Evaluado';
                        }
                    ],
                    // btn grid:
                    [
                        'class'             => 'yii\grid\ActionColumn',
                        'header'            => Yii::t('app', 'Acciones'),
                        'contentOptions'    => ['style' => 'width: 100px', 'class' => 'text-center'],
                        'template'          => '{descarga} {evaluar}',
                        'buttons'   => [

                            'descarga' => function ($url, $model, $key){
                                $link    = Url::toRoute(['/docente/evaluacion/descargar' , 'id' => $key ]);
                                $text    = Fa::icon('download')->fw();

                                return Html::a($text, $link, [
                                    'title'         =>  Yii::t('yii', 'Descargar Evaluacion') ,
                                    'class'         => 'text-info',
                                    'target'        => '_blank'
                                ]);
                            },
                            'evaluar' => function ($url, $model, $key){
                                $link    = Url::toRoute(['/docente/evaluacion/evaluar']);
                                $text    = Fa::icon('pencil-square-o')->fw();

                                return Html::a($text, $link, [
                                    'title'         =>  Yii::t('yii', 'Evaluar') ,
                                    'class'         => 'text-info evaluar-prueba',
                                    'data-id'       => $key,
                                ]);
                            },
                        ]
                    ],
                ],
            ]);
        ?>
    </div>
</div>
