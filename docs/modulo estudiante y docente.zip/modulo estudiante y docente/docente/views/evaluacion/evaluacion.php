<?php
use yii\helpers\Url;
use base\widgets\ActiveForm;
use yii\helpers\Html;
use base\widgets\faicons\Fa;
?>

<?php

//registros de js
$query =  <<<JS

$(document).on('click', '.evaluar-prueba', function(e){
e.preventDefault();
    var id = $(this).data('id');
    
    $.ajax({
        method:'post',
        url : $(this).attr('href'),
        data: {id:id},
        success: function(resp)
        {
            $('.modal-form .modal-body').html(resp);
            $('.modal-form').modal('show');
        }
    });
});

$(document).on('click', '.form-editar-evaluacion', function(e){
    $('.modal-form').modal('hide');
});

JS;

$this->registerJs($query)
?>

<!-- modal-->
<div class="modal modal-form fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="alert">
    <div class="modal-content">
      <div class="modal-body">
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="material-docente-default-index">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <?php echo Fa::icon($this->iconClass); ?>
                        <?php echo Yii::t('app', 'Evaluacion '). $nombreCurso; ?>
                    </h3>
                </div>
                <div class="panel-body" >
                    <div class="col-md-12 col-sm-12">
                        <?=$this->render('partial/_gridViewEvaluacion');?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>