<?php
use yii\helpers\Url;
use base\widgets\ActiveForm;
use yii\helpers\Html;
use base\widgets\faicons\Fa;

$this->registerJs(
    '
        (function(){

            modal.reset.default();

            modal.icon.attr("class", "fa fa-'. $this->iconClass .' fa-fw");
            modal.title.html("'. $this->H1 .'");
            modal.size("modal-md")
            modal.header.show();
            modal.header.btnClose.show();
            modal.body.show();
            modal.footer.hide();
        })();
    '
);
?>

<div class="material-docente-default-index">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <?=$this->render('partial/_gridViewCursada');?>
        </div>
    </div>
</div>