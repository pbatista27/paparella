<?php
    use yii\helpers\Url;
    use base\widgets\ActiveForm;
    use yii\helpers\Html;
    use base\widgets\faicons\Fa;


$js = <<< JS

    //varibla global
    var id_curso;

    $(document).on('change','#select-sucursal-curso',function(e){
            var value = $(this).val();
            var url = $(this).data('url');
            if(value.trim()==''){
                return false;
            }
            $.ajax({
                type:'post',
                url: url,
                data:{'id':value},
                success: function(resp)
                {
                    $('#select-curso-material').html('');
                    $('#select-curso-material').html(resp);
                }
            });
    });

    $(document).on('change','#select-curso-material',function(e){
            var value = $(this).val();
            id_curso = value
            var url = $(this).data('url');
            if(value.trim()==''){
                return false;
            }
            $.ajax({
                type:'post',
                url: url,
                data:{'id':value},
                success: function(resp)
                {
                    $('#gridView-menu').removeClass('hide');
                    $('#vista-grid-material').html('');
                    $('#vista-grid-material').html(resp);
                }
            });
    });

    $(document).on('click','a.documentos',function(e){
        e.preventDefault();
            var tipo = $(this).data('tipo');
            var url = $(this).attr('href');
            
            if(id_curso.trim()==''){
                return false;
            }

            $.ajax({
                type:'post',
                url: url,
                data:{'id':id_curso},
                success: function(resp)
                {
                    $('#vista-grid-material').html('');
                    $('#vista-grid-material').html(resp);
                }
            });
    });

        (function(){

            modal.reset.default();

            modal.icon.attr("class", "fa fa-$this->iconClass fa-fw");
            modal.title.html("$this->H1");
            modal.size("modal-70")
            modal.header.show();
            modal.header.btnClose.show();
            modal.body.show();
            modal.footer.hide();
        })();

JS;
$this->registerJs($js);
?>
<div class="material-default-index">
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="row">
                <div class="col-lg-4 col-md-4  col-md-offset-2">
                    <label for="sucursales">Seleccion Sucursal</label>
                    <?=Html::dropDownList('sucursales', $selection = null, $dataSucursal, $options = ['class'=>'form-control','prompt'=>'Seleccione sucursal','id'=>'select-sucursal-curso','data-url'=>Url::toRoute(['/docente/material-docente/curso'])]);?>
                </div>
                <div class="col-lg-4 col-md-4">
                    <label for="sucursales">Seleccion Curso</label>
                    <?=Html::dropDownList('cursos', $selection = null,[], $options = ['class'=>'form-control','prompt'=>'Seleccione Curso','id'=>'select-curso-material','data-url'=>Url::toRoute(['/docente/material-docente/material-estudiante'])]);?>
                </div>
            </div>
            <hr>
            <div class='row hide' id="gridView-menu"> 
                <div class="col-xs-12 col-sm-8 col-md-9">
                    <div id="vista-grid-material">
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>