<?php

namespace app\base\modules\docente\models;

use Yii;
use app\models\CursadaCalificacion;

class Evaluacion extends CursadaCalificacion
{
    const WEBROOT_PATH = '@app/data/uploads/cursos/examen/';
}