<?php

namespace base\modules\docente\models;


class MaterialDocente extends \app\models\CursoContenido
{
    const WEBROOT_PATH = '@app/data/uploads/cursos/';

}