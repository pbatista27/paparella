<?php

namespace app\base\modules\docente\models;


class Cursada extends \app\models\Cursada
{
    
}