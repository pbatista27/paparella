<?php

namespace app\base\modules\docente\controllers;

use base\Controller;

/**
 * Default controller for the `docente` module
 */
class DefaultController extends Controller
{
    /**
     * Renders the index view for the module
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }
}
