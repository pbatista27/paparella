<?php

namespace app\base\modules\docente\controllers;

use Yii;
use base\Controller;
use app\models\CursadaDocente;
use yii\helpers\ArrayHelper;
use yii\web\MethodNotAllowedHttpException;
use yii\web\HttpException;
use yii\helpers\Inflector;
use yii\data\ActiveDataProvider;
use app\base\modules\docente\models\Evaluacion;
use app\base\modules\docente\models\Cursada;
use yii\widgets\ActiveForm;
use yii\web\Session;

class EvaluacionController extends Controller 
{

    public $model;

    public function actionIndex()
    {

        $this->view->H1             = Yii::t('app','Docente / Evaluacion');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'file-text' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];

        $query = Cursada::find()
                ->select('*')
                ->from(Cursada::tableName() . ' as c')
                ->join('INNER JOIN','cursada_docente as cd','cd.id_cursada = c.id')
                ->andWhere('cd.id_docente = '. Yii::$app->user->identity->id);

        $this->model = new ActiveDataProvider([
            'query'         =>$query,
            'pagination'    => false,
            'sort'          => ['defaultOrder'=>'created_at desc']

        ]);

        return $this->renderAjax('index');

    }


    public function actionExamen($id)
    {
        $this->view->H1             = Yii::t('app','Docente / Evaluacion');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'file-text' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];

        $sql = Evaluacion::find()
                ->select('cc.id, cc.id_cursada, cc.id_estudiante, cc.archivo_estudiante,cc.fecha_subida, cc.aprobado, cc.status')
                ->from(Evaluacion::tableName() . ' as cc')
                ->join('INNER JOIN','cursada as c', 'c.id= cc.id_cursada')
                ->join('INNER JOIN','usuario as u', 'u.id = cc.id_docente')
                ->join('INNER JOIN','curso_sucursal as cs', 'cs.id = c.id_curso_sucursal')
                ->join('INNER JOIN','curso as cu', 'cu.id = cs.id_curso')
                ->andwhere('u.activo = 1')
                ->andWhere('u.id_perfil = 3')
                ->andWhere('cu.activo=1')
                ->andWhere('cu.id = :id',[':id'=>$id])
                ->andWhere('u.id ='. Yii::$app->user->identity->id);

        $this->model = new ActiveDataProvider([
            'query'      => $sql,
            'pagination' => false,
            'sort' => ['defaultOrder'=>'created_at desc']
        ]);

        $data = $sql->one();
        $params['nombreCurso'] = '';
        if(!is_null($data) )
            $params['nombreCurso'] = $data->getCursada()->one()->getCursoSucursal()->one()->getCurso()->one()->nombre;
        
        
        return $this->render('evaluacion',$params);
    }

    public function actionEvaluar()
    {
        if(Yii::$app->request->isPost)
        {
            if(Yii::$app->request->isAjax == false)
                throw new MethodNotAllowedHttpException(Yii::t('app', 'Petición invalida.'));

            $id = Yii::$app->request->post('id');

            $this->model = $this->findModel($id);

            $session = new Session();
            $session->open();
            $session->set('model',$this->model);
        }

        return $this->renderAjax('partial/_form');
    }

    public function actionRegistrarEvaluacion()
    {

        if(Yii::$app->request->isPost)
        {
            if(Yii::$app->request->isAjax == false)
                throw new MethodNotAllowedHttpException(Yii::t('app', 'Petición invalida.'));

            $this->model = Yii::$app->session->get('model');
            $this->model->status = 1;

            $this->model->load(Yii::$app->request->post());

            if(isset($_POST['ajax']))
                return $this->asJson( ActiveForm::validate($this->model) );

            if($this->model->save())
            {

                return $this->asJson([
                    'status'     => true,
                    'statusCode' => Yii::t('app','Accion completada!'),
                    'statusText' => Yii::t('app', 'Registro actualizado exitosamente'),
                ]);
            }
            else
                return $this->asJson([
                    'status' => false,
                    'statusText' => Yii::t('app','Error actualizar datos videos...'),
                ]);
        }

        return $this->redirect(['/docente/evaluacion']);

    }


    public function actionDescargar($id = null)
    {

        $file = $this->findModel($id);

        $src = (Yii::getAlias($file::WEBROOT_PATH . $file->archivo_estudiante, false))?: false;

        if(!$src || !is_file($src) || !is_readable($src) )
            throw new HttpException( 404, Yii::t('app', 'Contenido no disponible') );

        $ext = pathinfo($src, PATHINFO_EXTENSION);
        $fileName = Inflector::slug($file->archivo_estudiante) . ($ext ? '.'.$ext : null );

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        header('Content-Type: ' . finfo_file($finfo, $src));
        finfo_close($finfo);

        header('Content-Disposition: attachment; filename='. $fileName );
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');

        header('Content-Length: ' . filesize($src));
        ob_clean();
        flush();
        readfile($src);
    }
    

    protected function findModel($id)
	{
		$query = Evaluacion::find()->where('id=:id', [':id' => $id]);

		$file = $query->one();

		if($query->count() == 0)
			throw new HttpException( 404, Yii::t('app', 'Contenido no disponible') );

		return $query->one();
	}

} 