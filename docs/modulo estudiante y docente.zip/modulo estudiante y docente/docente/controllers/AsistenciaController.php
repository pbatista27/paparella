<?php

namespace app\base\modules\docente\controllers;
use Yii;
use base\Controller;
use yii\helpers\ArrayHelper;
use app\base\modules\docente\models\Cursada;
use yii\data\ActiveDataProvider;

class AsistenciaController extends Controller
{
    public $model;

    public function actionIndex()
    {

        $this->view->H1             = Yii::t('app','Docente / Cursos');
        $this->view->title          = $this->view->H1 . ' - ' .  Yii::$app->name ;
        $this->view->iconClass      = 'list' ;

        $this->view->breadcrumbs    = [
            ['label' => $this->view->H1 , 'url' => $this->currentUrl ]
        ];


        $query = Cursada::find()
                ->select('*')
                ->from(Cursada::tableName() . ' as c')
                ->join('INNER JOIN','cursada_docente as cd','cd.id_cursada = c.id')
                ->andWhere('cd.id_docente = '. Yii::$app->user->identity->id);

        $this->model = new ActiveDataProvider([
            'query'         =>$query,
            'pagination'    => false,
            'sort'          => ['defaultOrder'=>'created_at desc']

        ]);


        return $this->renderAjax('index');
    }
}